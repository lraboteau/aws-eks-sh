# Contributing to rtf-gitlab-ci

## Development Process

1. Create a feature branch from `main`
2. Make your changes
3. Test with a sample project
4. Update documentation if needed
5. Submit a merge request

## Testing Changes

Before submitting changes:

1. Validate YAML syntax
2. Test template inclusion
3. Verify scripts functionality
4. Update CHANGELOG.md

## Code Standards

- Use consistent indentation (2 spaces)
- Add comments for complex logic
- Follow GitLab CI best practices
- Ensure backwards compatibility