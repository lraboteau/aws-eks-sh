## `exchange.sh`

A **Bash** script to manage Anypoint Exchange assets in API-only mode. It can verify whether an asset exists, publish a new artifact, and provide simple wrappers for your CI/CD pipeline.

### Prerequisites

* Environment variables:

  * `ANYPOINT_BASE_URL` – Base URL of the Anypoint platform (e.g. `https://anypoint.mulesoft.com`)
  * `ACCESS_TOKEN` – OAuth bearer token exported by `auth.sh`
  * `ORG_ID` – Your Anypoint organization UUID
  * `EXCHANGE_GROUP_ID`, `ARTIFACT_ID`, `APP_VERSION` – Asset coordinates
  * `JAR_FILE` – Path to the built Mule application JAR
* Installed tools: `curl`, `jq`

---

## `verify_exchange_asset()`

Checks if the specified asset exists on Exchange and logs its details.

```bash
verify_exchange_asset() {
    local exchange_group_id=$1
    local artifact_id=$2
    local app_version=$3

    echo "🔍 Checking asset existence on Exchange..."

    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_BASE_URL}/exchange/api/v2/assets/${exchange_group_id}/${artifact_id}/${app_version}" \
        -H "Authorization: Bearer $ACCESS_TOKEN")

    local http_code="${response: -3}"
    local body="${response%???}"

    if [[ "$http_code" == "200" ]]; then
        echo "✅ Asset found on Exchange"
        # Parse key fields for visibility
        local asset_name=$(echo "$body" | jq -r '.name // "N/A"')
        local asset_type=$(echo "$body" | jq -r '.type // "N/A"')
        local created_date=$(echo "$body" | jq -r '.createdDate // "N/A"')
        echo "📋 Asset Details: Name=$asset_name, Type=$asset_type, Created=$created_date"
        return 0
    else
        echo "❌ Asset not found on Exchange (HTTP $http_code)"
        return 1
    fi
}
```

**What it does**

* Sends a GET request to `/exchange/api/v2/assets/{group}/{artifact}/{version}`
* Checks for HTTP 200 to confirm existence
* Logs the asset’s name, type, and creation date
* Returns success (0) if found, failure (1) otherwise

---

## `publish_to_exchange_api()`

Uploads the Mule application JAR to Exchange via the REST API.

```bash
publish_to_exchange_api() {
    local exchange_group_id=$1
    local artifact_id=$2
    local app_version=$3
    local jar_file=$4

    echo "📦 Publishing artifact to Anypoint Exchange via API..."
    echo "   Exchange Group ID: $exchange_group_id"
    echo "   Artifact ID: $artifact_id"
    echo "   Version: $app_version"
    echo "   Organization ID: $ORG_ID"
    echo "   JAR file: $jar_file"

    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_BASE_URL}/exchange/api/v2/assets" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -F "organizationId=${ORG_ID}" \
        -F "groupId=${exchange_group_id}" \
        -F "assetId=${artifact_id}" \
        -F "version=${app_version}" \
        -F "name=${APP_NAME}" \
        -F "classifier=mule-application" \
        -F "asset=@${jar_file};type=application/java-archive")

    local http_code="${response: -3}"
    local body="${response%???}"

    echo "📡 HTTP Response: $http_code"
    if [ ${#body} -gt 200 ]; then
        echo "📄 Response Body (truncated): ${body:0:200}..."
    else
        echo "📄 Response Body: $body"
    fi

    if [[ "$http_code" == "200" || "$http_code" == "201" ]]; then
        echo "✅ Exchange publication successful (HTTP $http_code)"
        return 0
    elif [[ "$http_code" == "409" ]]; then
        echo "ℹ️ Artifact already exists on Exchange (HTTP $http_code)"
        return 0
    else
        echo "❌ Error during Exchange publication (HTTP $http_code)"
        echo "📄 Full response body: $body"
        return 1
    fi
}
```

**What it does**

* Sends a multipart POST to `/exchange/api/v2/assets`
* Includes org ID, group ID, artifact ID, version, name, and the JAR file
* Handles:

  * **200/201** → success
  * **409** → conflict (already exists)
  * Others → error, prints full response

---

## `publish_to_exchange()`

High-level function to verify existence, publish if missing, and re-verify.

```bash
publish_to_exchange() {
    local exchange_group_id=$1
    local artifact_id=$2
    local app_version=$3
    local jar_file=$4

    echo "🎯 Starting Exchange publication (API-ONLY MODE)"
    echo "   Exchange Group ID: $exchange_group_id"
    echo "   Artifact ID: $artifact_id"
    echo "   Version: $app_version"
    echo "   NOTE: Skipping Maven deployment – using Exchange API only"

    # If already present, skip publishing
    if verify_exchange_asset "$exchange_group_id" "$artifact_id" "$app_version"; then
        echo "ℹ️ Asset already exists – nothing to do"
        return 0
    fi

    # Publish and re-verify
    echo "🔄 Publishing via Exchange API..."
    if publish_to_exchange_api "$exchange_group_id" "$artifact_id" "$app_version" "$jar_file"; then
        sleep 2  # allow for eventual consistency
        if verify_exchange_asset "$exchange_group_id" "$artifact_id" "$app_version"; then
            echo "✅ Exchange publication completed successfully"
            return 0
        else
            echo "⚠️ Publication succeeded but asset not yet visible (propagation delay)"
            return 0
        fi
    fi

    echo "❌ Exchange publication failed"
    return 1
}
```

**What it does**

1. Checks existing asset
2. If missing, calls `publish_to_exchange_api()`
3. Waits briefly, then re-verifies
4. Continues on propagation-delay warnings

---

## `deploy_to_exchange()`

Wrapper for CI pipelines that aborts on failure or confirms success.

```bash
deploy_to_exchange() {
    if ! publish_to_exchange "$EXCHANGE_GROUP_ID" "$ARTIFACT_ID" "$APP_VERSION" "$JAR_FILE"; then
        echo "❌ Exchange deployment failed"
        exit 1
    fi

    echo "✅ Exchange deployment completed successfully"
}
```

**What it does**

* Invokes `publish_to_exchange` with pre-exported variables
* Exits the script on failure
* Prints a success message on completion