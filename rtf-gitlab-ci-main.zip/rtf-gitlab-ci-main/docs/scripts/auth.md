## `auth.sh`

A **debug**-friendly Bash script to:

1. **Obtain** an OAuth2 bearer token from Anypoint
2. **Validate** that token against the Exchange API
3. Provide a single entry point to **authenticate**

### Prerequisites

Make sure the following environment variables are set:

* `ANYPOINT_BASE_URL` – Base URL of your Anypoint platform (e.g. `https://anypoint.mulesoft.com`)
* `CLIENT_ID` – OAuth client ID
* `CLIENT_SECRET` – OAuth client secret
* `jq` installed on your machine for JSON parsing

---

## `get_bearer_token()`

Retrieves a client-credentials token, logs debug details, and exports it as `ACCESS_TOKEN`.

```bash
#!/bin/bash
get_bearer_token() {
    echo "🔐 Retrieving Bearer Token..."
    echo "🌐 Using base URL: ${ANYPOINT_BASE_URL}"
    echo "🔑 Client ID: ${CLIENT_ID:0:8}..."  # show only first 8 chars

    local response=$(curl -s --location "${ANYPOINT_BASE_URL}/accounts/api/v2/oauth2/token" \
        --header 'Content-Type: application/json' \
        --data '{
            "grant_type": "client_credentials",
            "client_id": "'"${CLIENT_ID}"'",
            "client_secret": "'"${CLIENT_SECRET}"'"
        }')

    echo "🔍 Token response received (length: ${#response})"

    local access_token=$(echo "$response" | jq -r '.access_token')

    if [ "$access_token" == "null" ] || [ -z "$access_token" ]; then
        echo "❌ Error retrieving Bearer Token"
        echo "Response: $response"
        exit 1
    fi

    export ACCESS_TOKEN="$access_token"
    echo "✅ Authentication successful"
    echo "🔑 Token length: ${#ACCESS_TOKEN}"
    echo "🔑 Token prefix: ${ACCESS_TOKEN:0:20}..."
}
```

**What it does**

* Logs steps with emojis for clarity
* Calls the Anypoint OAuth2 endpoint
* Validates that `access_token` is non-empty
* Exits with an error message if token acquisition fails
* Exports `ACCESS_TOKEN` for downstream API calls

---

## `validate_token_debug()`

Checks that the newly acquired token works by hitting the Exchange assets endpoint.

```bash
validate_token_debug() {
    if [ -z "$ACCESS_TOKEN" ]; then
        echo "❌ Error: ACCESS_TOKEN not set"
        return 1
    fi

    echo "🔍 Validating token..."
    echo "🌐 Base URL: ${ANYPOINT_BASE_URL}"
    echo "🔑 Token length: ${#ACCESS_TOKEN}"

    local test_url="${ANYPOINT_BASE_URL}/exchange/api/v2/assets"
    echo "🎯 Testing endpoint: $test_url"

    local response=$(curl -s -w "%{http_code}" \
        "$test_url" \
        -H "Authorization: Bearer $ACCESS_TOKEN")

    local http_code="${response: -3}"
    local body="${response%???}"

    echo "📡 HTTP Response Code: $http_code"
    echo "📄 Response body length: ${#body}"

    if [[ "$http_code" == "200" ]]; then
        echo "✅ Token validation successful"
        return 0
    else
        echo "❌ Token validation failed (HTTP $http_code)"
        echo "📄 Response body: ${body:0:500}..."  # first 500 chars
        return 1
    fi
}
```

**What it does**

* Verifies `ACCESS_TOKEN` is set
* Hits `/exchange/api/v2/assets` with the bearer token
* Prints HTTP status and body-length for debugging
* Returns success only if HTTP 200

---

## `authenticate()`

A single-call wrapper that fetches **and** validates the token:

```bash
authenticate() {
    get_bearer_token
    validate_token_debug
}
```

**Usage**

1. Source the script in your shell or CI job:

   ```bash
   source ./auth.sh
   ```

2. Call the authentication flow:

   ```bash
   authenticate
   ```

On success, you’ll have `$ACCESS_TOKEN` exported and ready for further API calls.