## `maven.sh`

A **Bash** script for extracting Maven project coordinates and locating the built JAR in your CI/CD pipeline.

### Prerequisites

* A valid `pom.xml` in the repository root
* `mvn` (Maven) installed and on your `PATH`
* Environment variables (exported by `config.sh` or your CI):

  * `CI_PIPELINE_IID` – Unique pipeline/build identifier
  * `ORG_ID` – Your Anypoint organization UUID

---

## `get_pom_property()`

Retrieves a single Maven property from `pom.xml` using the Maven Help Plugin.

```bash
get_pom_property() {
    local property=$1
    if [ -f ".m2/settings.xml" ]; then
        mvn -s .m2/settings.xml help:evaluate \
            -Dexpression=${property} -q -DforceStdout 2>/dev/null
    else
        mvn help:evaluate \
            -Dexpression=${property} -q -DforceStdout 2>/dev/null
    fi
}
```

**What it does**

* Accepts the property name (e.g. `project.artifactId`) as an argument
* If a local Maven settings file (`.m2/settings.xml`) exists, uses it
* Runs `mvn help:evaluate` in quiet mode and prints only the property value

---

## `extract_project_info()`

Gathers and validates key project coordinates, then exports them for downstream scripts.

```bash
extract_project_info() {
    echo "🔍 Extracting project information from pom.xml..."
    
    local artifact_id=$(get_pom_property "project.artifactId")
    local group_id=$(get_pom_property "project.groupId")
    local project_version=$(get_pom_property "project.version")
    
    # Verify Maven properties were retrieved
    if [ -z "$artifact_id" ] || [ -z "$group_id" ] || [ -z "$project_version" ]; then
        echo "❌ Error: Unable to retrieve Maven properties from pom.xml"
        echo "Artifact ID: '$artifact_id'"
        echo "Group ID: '$group_id'"
        echo "Project Version: '$project_version'"
        echo "Current directory: $(pwd)"
        echo "POM file exists: $([ -f pom.xml ] && echo 'Yes' || echo 'No')"
        exit 1
    fi
    
    # Build application version (strip SNAPSHOT and append pipeline ID)
    local app_version
    if [[ "$project_version" == *"-SNAPSHOT"* ]]; then
        local clean_version="${project_version%-SNAPSHOT}"
        app_version="${clean_version}-${CI_PIPELINE_IID}"
    else
        app_version="${project_version}-${CI_PIPELINE_IID}"
    fi
    
    # Use ORG_ID as the Exchange groupId
    local exchange_group_id="$ORG_ID"
    
    # Export for other scripts
    export ARTIFACT_ID="$artifact_id"
    export GROUP_ID="$group_id"
    export PROJECT_VERSION="$project_version"
    export APP_VERSION="$app_version"
    export EXCHANGE_GROUP_ID="$exchange_group_id"
    
    echo "📋 Project Information:"
    echo "   Artifact ID: $artifact_id"
    echo "   Group ID (pom.xml): $group_id"
    echo "   Exchange Group ID: $exchange_group_id"
    echo "   Project Version: $project_version"
    echo "   App Version (for Exchange): $app_version"
    echo "   Application Name: $APP_NAME"
    
    echo "✅ Project information extracted successfully"
}
```

**What it does**

1. Calls `get_pom_property` to read `artifactId`, `groupId`, and `version`.
2. Exits with an error if any are empty or retrieval fails.
3. Strips `-SNAPSHOT` from the version (if present) and appends `CI_PIPELINE_IID`.
4. Overrides `GROUP_ID` for Exchange to use `ORG_ID`.
5. Exports:

   * `ARTIFACT_ID`
   * `GROUP_ID`
   * `PROJECT_VERSION`
   * `APP_VERSION`
   * `EXCHANGE_GROUP_ID`

---

## `find_jar_file()`

Locates the built Mule application JAR in the `target/` directory.

```bash
find_jar_file() {
    echo "📁 Looking for JAR file in target directory..."
    
    local jar_file=$(find target -name "*-mule-application.jar" | head -n 1)
    if [ -z "$jar_file" ]; then
        jar_file=$(find target -name "*.jar" | head -n 1)
    fi
    
    if [ -z "$jar_file" ]; then
        echo "❌ No JAR file found in target/"
        echo "Contents of target directory:"
        ls -la target/ || echo "target directory not found"
        exit 1
    fi
    
    export JAR_FILE="$jar_file"
    echo "📁 JAR file found: $jar_file"
    echo "📊 File size: $(du -h "$jar_file" | cut -f1)"
    
    return 0
}
```

**What it does**

* Searches first for `*-mule-application.jar`, then for any `.jar`.
* Exits with an error if nothing is found.
* Exports `JAR_FILE` with the path to the discovered archive.
* Logs the file path and its size.

---

## `setup_maven_info()`

Convenience wrapper to run both extraction and file lookup.

```bash
setup_maven_info() {
    extract_project_info
    find_jar_file
}
```

**What it does**

* Executes `extract_project_info()` and then `find_jar_file()`.
* After calling, you have these exported for downstream use:

  * `ARTIFACT_ID`, `GROUP_ID`, `PROJECT_VERSION`, `APP_VERSION`, `EXCHANGE_GROUP_ID`, and `JAR_FILE`.