## `config.sh`

A **Bash** script to configure and validate the deployment environment for MuleSoft RTF on the US control plane (API-only mode).

### What It Does

1. **Exports** default URLs and resource limits
2. **Validates** that all required environment variables are set
3. **Sets up** the application name based on CI variables
4. **Checks** for required CLI tools
5. **Displays** a deployment summary
6. Provides a **single entry point** to run all checks: `configure_environment()`

---

### Exports & Defaults

At the top of the script, key URLs and default resource settings are exported:

```bash
#!/bin/bash

# US control plane configuration
export ANYPOINT_BASE_URL="https://anypoint.mulesoft.com"
export ANYPOINT_API_URL="https://anypoint.mulesoft.com/amc/application-manager/api/v2"

# Default resource limits
export DEFAULT_CPU_LIMIT="1000m"
export DEFAULT_CPU_RESERVED="200m"
export DEFAULT_MEMORY_LIMIT="1Gi"
export DEFAULT_MEMORY_RESERVED="1Gi"
export DEFAULT_REPLICAS=1
```

---

## `validate_environment()`

Ensures that all required CI and Anypoint variables are present:

```bash
validate_environment() {
    local required_vars=(
        "CI_PIPELINE_IID"
        "CLIENT_ID"
        "CLIENT_SECRET"
        "ORG_ID"
        "ENVIRONMENT_ID"
        "TARGET_ID"
        "CI_PROJECT_NAME"
        "CI_COMMIT_SHA"
    )
    
    local missing_vars=()
    
    for var in "${required_vars[@]}"; do
        if [ -z "${!var}" ]; then
            missing_vars+=("$var")
        fi
    done
    
    if [ ${#missing_vars[@]} -ne 0 ]; then
        echo "❌ Error: Missing required environment variables:"
        printf "   - %s\n" "${missing_vars[@]}"
        exit 1
    fi
    
    echo "✅ All required environment variables are set"
}
```

**What it does**

* Defines a list of **required** environment variable names
* Iterates to collect any that are **unset** or empty
* If any are missing, prints a list and **exits** with an error
* Otherwise, confirms all variables are present

---

## `setup_app_name()`

Determines the `APP_NAME` based on an optional override or CI project name:

```bash
setup_app_name() {
    if [ -n "$MULE_APP_NAME" ]; then
        export APP_NAME="$MULE_APP_NAME"
    else
        export APP_NAME="muleapp-${CI_PROJECT_NAME}"
    fi
    
    echo "📱 Application name: $APP_NAME"
}
```

**What it does**

* If `MULE_APP_NAME` is set, uses it directly
* Otherwise constructs `APP_NAME` as `muleapp-<CI_PROJECT_NAME>`
* Exports `APP_NAME` and prints it for logging

---

## `check_dependencies()`

Verifies that required command-line tools are installed:

```bash
check_dependencies() {
    local required_tools=("jq" "curl" "mvn")
    local missing_tools=()
    
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    if [ ${#missing_tools[@]} -ne 0 ]; then
        echo "❌ Error: Missing required tools:"
        printf "   - %s\n" "${missing_tools[@]}"
        exit 1
    fi
    
    echo "✅ All required tools are available"
}
```

**What it does**

* Defines an array of **tool names**: `jq`, `curl`, `mvn`
* Checks each with `command -v`
* If any are missing, lists them and **exits**
* Otherwise, confirms all dependencies are installed

---

## `display_summary()`

Prints a summary of the deployment context:

```bash
display_summary() {
    echo "=== RTF MuleSoft Deployment - US Control Plane (API-ONLY MODE) ==="
    echo "Project: $CI_PROJECT_NAME"
    echo "App Name: $APP_NAME"
    echo "Pipeline ID: $CI_PIPELINE_IID"
    echo "Commit SHA: ${CI_COMMIT_SHA:0:8}"
    echo "⚠️ NOTE: This version skips Maven deployment and uses Exchange API only"
}
```

**What it does**

* Logs the **project name**, **app name**, **pipeline ID**, and a **shortened commit SHA**
* Warns that this script runs in **API-only** mode (no Maven deploy)

---

## `configure_environment()`

Single entry point to run all setup and validation steps:

```bash
configure_environment() {
    echo "🔧 Setting up deployment environment..."
    
    display_summary
    validate_environment
    setup_app_name
    check_dependencies
    
    echo "✅ Environment configuration completed"
}
```

**What it does**

1. Prints a start message
2. Calls in sequence:

   * `display_summary`
   * `validate_environment`
   * `setup_app_name`
   * `check_dependencies`
3. Prints a completion message