## `deployment.sh`

A **Bash** script containing functions to manage MuleSoft Runtime Fabric deployments via the Anypoint API. It handles checking for existing deployments, creating deployment payloads, deploying new apps, updating existing apps, and optionally waiting for completion.

---

### Shebang & Script Directory Resolution

```bash
#!/bin/bash

# Determine the directory where this script resides
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
```

* Uses `BASH_SOURCE` to locate the script’s directory for reliable relative sourcing.&#x20;

---

## `get_app_deployment()`

Retrieves the deployment ID of an already-deployed application by name.

```bash
get_app_deployment() {
    local response=$(curl -s "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    
    local app_id=$(echo "$response" | jq -r ".items[] | select(.name == \"$APP_NAME\").id")
    
    if [ "$app_id" != "null" ] && [ -n "$app_id" ]; then
        echo "$app_id"
    else
        echo ""
    fi
}
```

**What it does**

* Calls the RTF deployments endpoint to list all deployments
* Filters by `.name == $APP_NAME` to find the matching ID
* Returns the ID if found, otherwise an empty string&#x20;

---

## `create_deployment_json()`

Constructs the JSON payload for deploying or updating the application.

```bash
create_deployment_json() {
    local app_version=$1
    local artifact_id=$2
    local group_id=$3
    
    cat <<EOF
{
    "name": "${APP_NAME}",
    "labels": [],
    "target": {
        "provider": "MC",
        "targetId": "${TARGET_ID}",
        "deploymentSettings": {
            "resources": {
                "cpu": {
                    "limit": "${CPU_LIMIT:-$DEFAULT_CPU_LIMIT}",
                    "reserved": "${CPU_RESERVED:-$DEFAULT_CPU_RESERVED}"
                },
                "memory": {
                    "limit": "${MEMORY_LIMIT:-$DEFAULT_MEMORY_LIMIT}",
                    "reserved": "${MEMORY_RESERVED:-$DEFAULT_MEMORY_RESERVED}"
                }
            },
            "clustered": false,
            "enforceDeployingReplicasAcrossNodes": true,
            "http": {
                "inbound": {
                    "publicUrl": "${PUBLIC_URL:-}"
                }
            },
            "jvm": {},
            "runtimeVersion": "",
            "lastMileSecurity": true,
            "updateStrategy": "rolling",
            "disableAmLogForwarding": true,
            "runtime": {
                "releaseChannel": "LTS",
                "java": "17"
            }
        },
        "replicas": ${REPLICAS:-$DEFAULT_REPLICAS}
    },
    "application": {
        "ref": {
            "groupId": "${group_id}",
            "artifactId": "${artifact_id}",
            "version": "${app_version}",
            "packaging": "jar"
        },
        "assets": [],
        "desiredState": "STARTED",
        "configuration": {
            "mule.agent.application.properties.service": {
                "applicationName": "${APP_NAME}",
                "properties": {
                    "anypoint.platform.analytics_base_uri": "",
                    "anypoint.platform.base_uri": "${ANYPOINT_BASE_URL}",
                    "deploy.application.name": "${APP_NAME}",
                    "anypoint.platform.config.analytics.agent.enabled": "true"
                },
                "secureProperties": {
                    "config.encryptionkey": "${CONFIG_ENCRYPTION_KEY:-}"
                }
            }
        }
    }
}
EOF
}
```

**What it does**

* Accepts `app_version`, `artifact_id`, and `group_id` as parameters
* Embeds CPU, memory, and replica defaults (with overrides)
* Defines runtime and application reference details&#x20;

---

## `deploy_new_app()`

Performs a **POST** to create a fresh deployment.

```bash
deploy_new_app() {
    local deployment_json=$1
    
    echo "🚀 Deploying new application..."
    
    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -X POST \
        -d "$deployment_json")
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [[ "$http_code" == "200" || "$http_code" == "202" ]]; then
        echo "✅ Deployment successful (HTTP $http_code)"
        local deployment_id=$(echo "$body" | jq -r '.id // "N/A"')
        local deployment_status=$(echo "$body" | jq -r '.status // "N/A"')
        echo "📋 Deployment ID: $deployment_id"
        echo "📊 Initial Status: $deployment_status"
        return 0
    else
        echo "❌ Deployment error (HTTP $http_code)"
        echo "📄 Response: $body"
        return 1
    fi
}
```

**What it does**

* Sends the JSON payload to the deployments endpoint
* Checks for HTTP `200` or `202` success codes
* Parses and logs the new deployment’s `id` and `status`&#x20;

---

## `update_existing_app()`

Performs a **PATCH** to update an existing deployment by ID.

```bash
update_existing_app() {
    local app_id=$1
    local deployment_json=$2
    
    echo "🔄 Updating existing application (ID: $app_id)..."
    
    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments/${app_id}" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -X PATCH \
        -d "$deployment_json")
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [[ "$http_code" == "200" || "$http_code" == "202" ]]; then
        echo "✅ Update successful (HTTP $http_code)"
        local deployment_status=$(echo "$body" | jq -r '.status // "N/A"')
        local app_status=$(echo "$body" | jq -r '.application.status // "N/A"')
        echo "📊 Deployment Status: $deployment_status"
        echo "📱 Application Status: $app_status"
        return 0
    else
        echo "❌ Update error (HTTP $http_code)"
        echo "📄 Response: $body"
        return 1
    fi
}
```

**What it does**

* Sends a PATCH with the updated payload
* Validates HTTP response codes
* Logs the updated deployment and application statuses&#x20;

---

## `wait_for_deployment()`

Polls the deployment status until it’s **DEPLOYED** and **RUNNING**, or until timeout.

```bash
wait_for_deployment() {
    local app_id=$1
    local max_wait=${DEPLOYMENT_TIMEOUT:-300}  # default 5 minutes
    local wait_time=0
    local check_interval=10
    
    if [ "$WAIT_FOR_DEPLOYMENT" != "true" ]; then
        echo "ℹ️ Skipping deployment status check (WAIT_FOR_DEPLOYMENT not set to true)"
        return 0
    fi
    
    echo "⏳ Waiting for deployment to complete (max ${max_wait}s)..."
    
    while [ $wait_time -lt $max_wait ]; do
        local response=$(curl -s "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments/${app_id}" \
            -H "Authorization: Bearer $ACCESS_TOKEN")
        
        local deployment_status=$(echo "$response" | jq -r '.status // "UNKNOWN"')
        local app_status=$(echo "$response" | jq -r '.application.status // "UNKNOWN"')
        
        echo "📊 Status check: Deployment=$deployment_status, Application=$app_status"
        
        if [[ "$deployment_status" == "DEPLOYED" && "$app_status" == "RUNNING" ]]; then
            echo "✅ Deployment completed successfully!"
            return 0
        elif [[ "$deployment_status" == "FAILED" || "$app_status" == "FAILED" ]]; then
            echo "❌ Deployment failed!"
            return 1
        fi
        
        sleep $check_interval
        wait_time=$((wait_time + check_interval))
    done
    
    echo "⏰ Deployment timeout reached (${max_wait}s)"
    return 1
}
```

**What it does**

* Only runs if `WAIT_FOR_DEPLOYMENT=true`
* Polls every 10 s until success or failure
* Times out after `DEPLOYMENT_TIMEOUT` seconds&#x20;

---

## `deploy_to_runtime_fabric()`

Top-level function that orchestrates deployment or update, then optionally waits.

```bash
deploy_to_runtime_fabric() {
    echo "🚀 Starting Runtime Fabric deployment..."
    
    echo "🔍 Checking for existing application: $APP_NAME"
    local existing_app_id=$(get_app_deployment)
    
    echo "🔧 Creating deployment JSON..."
    local deployment_json=$(create_deployment_json "$APP_VERSION" "$ARTIFACT_ID" "$EXCHANGE_GROUP_ID")
    
    echo "📄 Deployment Summary:"
    echo "   Target ID: $TARGET_ID"
    echo "   Organization ID: $ORG_ID"
    echo "   Environment ID: $ENVIRONMENT_ID"
    echo "   Asset Reference: $EXCHANGE_GROUP_ID:$ARTIFACT_ID:$APP_VERSION"
    echo "   Deployment Method: Exchange API Only (Maven skipped)"
    
    if [ -z "$existing_app_id" ]; then
        echo "📦 Application not found - Deploying new application"
        if deploy_new_app "$deployment_json"; then
            sleep 2
            local new_app_id=$(get_app_deployment)
            if [ -n "$new_app_id" ]; then
                wait_for_deployment "$new_app_id"
            fi
        else
            echo "❌ New application deployment failed"
            exit 1
        fi
    else
        echo "🔄 Application found with ID: $existing_app_id - Updating"
        if update_existing_app "$existing_app_id" "$deployment_json"; then
            wait_for_deployment "$existing_app_id"
        else
            echo "❌ Application update failed"
            exit 1
        fi
    fi
    
    echo "✅ Runtime Fabric deployment completed successfully"
}
```

**What it does**

1. Checks for an existing deployment
2. Builds the JSON payload
3. Logs summary information
4. Chooses to create or update the deployment
5. Optionally polls for completion&#x20;