## `deploy.sh`

A **Bash** script that orchestrates the full MuleSoft Runtime Fabric deployment pipeline by sourcing modular scripts and running each deployment step in sequence.

### What It Does

1. **Sources** supporting modules: `config.sh`, `auth.sh`, `maven.sh`, `exchange.sh`, and `deployment.sh`
2. Defines helper functions for summarizing results
3. Implements a `main()` function to run all steps in order
4. Handles errors and exits immediately on failure
5. Traps any error to report which command failed

---

### Shebang & Script Directory Resolution

```bash
#!/bin/bash

# Determine the directory where this script resides
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
```

* Uses `BASH_SOURCE` to get the absolute path of the script
* Ensures subsequent `source` calls use the correct directory context&#x20;

---

## Sourcing Module Scripts

```bash
# Source all module scripts
source "${SCRIPT_DIR}/config.sh"
source "${SCRIPT_DIR}/auth.sh"
source "${SCRIPT_DIR}/maven.sh"
source "${SCRIPT_DIR}/exchange.sh"
source "${SCRIPT_DIR}/deployment.sh"
```

* Imports definitions of functions and environment setup from each module
* Assumes these scripts are located alongside `deploy.sh`&#x20;

---

## `display_final_summary()`

Displays a summary of the completed deployment, including application details and the control plane used.

```bash
display_final_summary() {
    echo "=== Deployment completed ==="
    echo "🎉 Success! Application '$APP_NAME' has been deployed to Runtime Fabric"
    echo "📦 Published to Exchange: $EXCHANGE_GROUP_ID:$ARTIFACT_ID:$APP_VERSION"
    echo "🌐 Control Plane: $ANYPOINT_BASE_URL"
    echo "📊 Deployment Details:"
    echo "   - Organization: $ORG_ID"
    echo "   - Environment: $ENVIRONMENT_ID"
    echo "   - Target: $TARGET_ID"
    echo "   - Pipeline: $CI_PIPELINE_IID"
    echo "   - Commit: ${CI_COMMIT_SHA:0:8}"
}
```

**What it does**

* Prints a clear “Deployment completed” banner
* Shows which application (`$APP_NAME`) was deployed
* Lists the published Exchange coordinates (`$EXCHANGE_GROUP_ID:$ARTIFACT_ID:$APP_VERSION`)
* Repeats the control plane URL for clarity
* Summarizes CI and environment metadata for auditability&#x20;

---

## `main()`

The primary entry point that runs each step of the deployment in order and handles success messaging.

```bash
main() {
    echo "🚀 Starting MuleSoft RTF Deployment Pipeline..."
    
    # Step 1: Configure environment and validate prerequisites
    configure_environment
    
    # Step 2: Authenticate with Anypoint Platform
    authenticate
    
    # Step 3: Extract Maven project information
    setup_maven_info
    
    # Step 4: Deploy to Anypoint Exchange
    deploy_to_exchange
    
    # Step 5: Deploy to Runtime Fabric
    deploy_to_runtime_fabric
    
    # Step 6: Display final summary
    display_final_summary
    
    echo "✅ Deployment pipeline completed successfully!"
}
```

**What it does**

1. Logs the start of the pipeline
2. Calls, in sequence:

   * `configure_environment` (from `config.sh`)
   * `authenticate` (from `auth.sh`)
   * `setup_maven_info` (from `maven.sh`)
   * `deploy_to_exchange` (from `exchange.sh`)
   * `deploy_to_runtime_fabric` (from `deployment.sh`)
3. Prints “completed successfully” when all steps pass&#x20;

---

## Error Handling & Trapping

```bash
# Exit immediately if any command fails
set -e  

# Report which command failed on exit
trap 'echo "❌ Deployment pipeline failed at step: $BASH_COMMAND"' ERR
```

* `set -e` ensures the script stops on the first error
* A `trap` on `ERR` reports the exact command (`$BASH_COMMAND`) that caused the failure&#x20;

---

## Script Execution

At the end of the file, `main` is invoked with any passed arguments:

```bash
# Execute main function
main "$@"
```

**Usage**

1. Make sure all module scripts (`config.sh`, `auth.sh`, `maven.sh`, `exchange.sh`, `deployment.sh`) are in the same directory as `deploy.sh`.

2. Ensure `deploy.sh` is executable:

   ```bash
   chmod +x deploy.sh
   ```

3. Run the deployment pipeline:

   ```bash
   ./deploy.sh
   ```

On success, you will see detailed logs for each step and a final summary confirming deployment.