// Custom scripts for documentation
document.addEventListener('DOMContentLoaded', function() {
    // Automatic copying of code examples
    const codeBlocks = document.querySelectorAll('pre code');
    
    codeBlocks.forEach(function(block) {
      // Add a copy button if not already present
      if (!block.parentElement.querySelector('.copy-button')) {
        const button = document.createElement('button');
        button.className = 'copy-button';
        button.textContent = 'Copy';
        button.onclick = function() {
          navigator.clipboard.writeText(block.textContent);
          button.textContent = 'Copied !';
          setTimeout(() => button.textContent = 'Copy', 2000);
        };
        block.parentElement.appendChild(button);
      }
    });
    
    // Analytics or tracking if necessary
    console.log('Documentation GitLab CI Templates loaded');
  });