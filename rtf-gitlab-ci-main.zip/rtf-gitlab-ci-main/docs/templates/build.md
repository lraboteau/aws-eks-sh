## `build.yml`

A **GitLab CI/CD** pipeline template that:

1. Installs prerequisites (`jq`)
2. Requests an OAuth2 bearer token from Anypoint
3. Generates a Maven `settings.xml` with the token
4. Builds the Mule application using Maven
5. Exposes the resulting JAR as a build artifact

### Sequence Diagram

```mermaid
sequenceDiagram
    actor Runner as GitLab Runner
    participant AP as Anypoint Token API
    participant FS as File System
    participant Maven as Maven

    Runner->>Runner: apt-get update && install jq
    Runner->>FS: mkdir -p .m2
    Runner->>AP: POST /accounts/api/v2/oauth2/token (client_credentials)
    AP-->>Runner: { "access_token": "…" }
    Runner->>FS: write .m2/settings.xml with Authorization header
    Runner->>Maven: mvn clean compile
    Maven-->>Maven: project compilation
    Runner->>Maven: mvn package -DskipTests
    Runner->>FS: ls -la target/
    Runner->>FS: find target -name "*.jar"
```

### Full `build.yml` Snippet

```yaml
.build_template: &build_template
  image: maven:3.9.6-eclipse-temurin-17
  before_script:
    - apt-get update && apt-get install -y jq
    - mkdir -p .m2
    - echo "Requesting Anypoint Platform OAuth token..."
    - |
      RESPONSE=$(curl -s -X POST https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token \
        -H 'Content-Type: application/x-www-form-urlencoded' \
        -d "grant_type=client_credentials&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}")
    - export ANYPOINT_TOKEN=$(echo "$RESPONSE" | jq -r '.access_token')
    - |
      if [ -z "$ANYPOINT_TOKEN" ] || [ "$ANYPOINT_TOKEN" = "null" ]; then
        echo "Failed to fetch access token. Response was: $RESPONSE"
        exit 1
      fi
    - echo "Token acquired."
    - echo "Generating Maven settings.xml with Bearer token..."
    - |
      cat > .m2/settings.xml << 'EOF'
      <?xml version="1.0" encoding="UTF-8"?>
      <settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0
                                    http://maven.apache.org/xsd/settings-1.0.0.xsd">
        <servers>
          <server>
            <id>anypoint-exchange-v3</id>
            <configuration>
              <httpHeaders>
                <property>
                  <name>Authorization</name>
                  <value>Bearer ${ANYPOINT_TOKEN}</value>
                </property>
              </httpHeaders>
            </configuration>
          </server>
          <server>
            <id>mule-enterprise</id>
            <configuration>
              <httpHeaders>
                <property>
                  <name>Authorization</name>
                  <value>Bearer ${ANYPOINT_TOKEN}</value>
                </property>
              </httpHeaders>
            </configuration>
          </server>
        </servers>
      </settings>
      EOF

build:
  <<: *build_template
  stage: build
  script:
    - echo "Building Mule application with Connected App + Bearer token..."
    - mvn $MAVEN_CLI_OPTS clean compile
    - mvn $MAVEN_CLI_OPTS package -DskipTests
    - echo "Build completed successfully"
    - ls -la target/
    - echo "Checking produced artifacts:"
    - find target -name "*.jar" -exec ls -la {} \;
  artifacts:
    paths:
      - target/*.jar
      - pom.xml
    expire_in: 1 hour
```

