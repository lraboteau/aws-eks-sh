## `deploy-rtf.yml`

A **GitLab CI/CD** job that deploys the Mule application to Runtime Fabric using API-only scripts.

**What it does**

1. Declares the job in the `deploy-rtf` stage and uses a Maven Docker image.&#x20;
2. Depends on artifacts from `build` and the successful execution of `deploy-exchange`.&#x20;
3. Installs prerequisites (`curl`, `jq`) and prepares the Maven settings file.&#x20;
4. Sources and runs:

   * `config.sh` → `configure_environment`
   * `auth.sh`   → `authenticate`
   * `maven.sh`  → `setup_maven_info`
   * `deployment.sh` → `deploy_to_runtime_fabric`&#x20;
5. Exits with error on any failure and prints a success message.&#x20;

### Sequence Diagram

```mermaid
sequenceDiagram
    actor Runner as GitLab Runner
    participant FS as File System
    participant Config as config.sh
    participant Auth as auth.sh
    participant AP as Anypoint Token API
    participant MavenScript as maven.sh
    participant Maven as Maven
    participant DeploymentScript as deployment.sh
    participant RTFAPI as Runtime Fabric API

    Runner->>Runner: apt-get update && install curl jq
    Runner->>FS: mkdir -p .m2
    Runner->>FS: cp .m2/settings.xml .m2/settings.xml
    Runner->>FS: chmod +x scripts/*.sh

    Runner->>Config: source scripts/config.sh
    Runner->>Config: configure_environment()
    Config-->>Runner: environment configured

    Runner->>Auth: source scripts/auth.sh
    Runner->>Auth: authenticate()
    Auth->>AP: POST /accounts/api/v2/oauth2/token
    AP-->>Auth: { access_token }
    Auth->>AP: GET /exchange/api/v2/assets
    AP-->>Auth: HTTP 200
    Auth-->>Runner: ACCESS_TOKEN set

    Runner->>MavenScript: source scripts/maven.sh
    Runner->>MavenScript: setup_maven_info()
    MavenScript->>Maven: get_pom_property(...)
    Maven-->>MavenScript: artifact coordinates
    MavenScript->>FS: find target JAR
    FS-->>MavenScript: JAR path
    MavenScript-->>Runner: ARTIFACT_ID & JAR_FILE set

    Runner->>DeploymentScript: source scripts/deployment.sh
    Runner->>DeploymentScript: deploy_to_runtime_fabric()
    DeploymentScript->>RTFAPI: GET /deployments (check)
    RTFAPI-->>DeploymentScript: existing or not
    DeploymentScript->>RTFAPI: POST or PATCH /deployments
    RTFAPI-->>DeploymentScript: HTTP 200/202
    DeploymentScript->>RTFAPI: GET /deployments/{id} polls
    RTFAPI-->>DeploymentScript: DEPLOYED & RUNNING
    DeploymentScript-->>Runner: deployment completed

    Runner-->>Runner: echo "✅ RTF deployment completed"
```

### Full `deploy-rtf.yml` Snippet

```yaml
deploy-rtf:
  stage: deploy-rtf
  image: maven:3.9.6-eclipse-temurin-17
  needs:
    - job: build
      artifacts: true
    - job: deploy-exchange
      artifacts: false
  before_script:
    - apt-get update && apt-get install -y curl jq
    - mkdir -p .m2
    - cp .m2/settings.xml .m2/settings.xml || echo "Settings file not found"
    - chmod +x scripts/*.sh
  script:
    - source scripts/config.sh
    - configure_environment
    - source scripts/auth.sh
    - authenticate
    - source scripts/maven.sh
    - setup_maven_info
    - source scripts/deployment.sh
    - deploy_to_runtime_fabric
    - echo "✅ RTF deployment completed"
```