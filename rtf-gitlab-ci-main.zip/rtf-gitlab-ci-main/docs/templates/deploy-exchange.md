## `deploy-exchange.yml`

A **GitLab CI/CD** job that publishes your built Mule application JAR to Anypoint Exchange using the API-only deployment scripts.

**What it does**

1. Runs in the `deploy-exchange` stage using a Maven image
2. Fetches artifacts from the `build` job
3. Installs prerequisites (`curl`, `jq`) and prepares the Maven settings
4. Sources and runs:

   * `config.sh` → `configure_environment`
   * `auth.sh`   → `authenticate`
   * `maven.sh`  → `setup_maven_info`
   * `exchange.sh` → `deploy_to_exchange`
5. Exits with an error if any step fails; otherwise prints a success message

---

### Sequence Diagram

```mermaid
sequenceDiagram
    actor Runner as GitLab Runner
    participant FS as File System
    participant Config as config.sh
    participant Auth as auth.sh
    participant AP as Anypoint Token API
    participant MavenScript as maven.sh
    participant Maven as Maven
    participant ExchangeScript as exchange.sh
    participant ExchangeAPI as Exchange API

    Runner->>Runner: apt-get update && install curl jq
    Runner->>FS: mkdir -p .m2
    Runner->>FS: cp .m2/settings.xml || echo "not found"
    Runner->>FS: chmod +x scripts/*.sh

    Runner->>Config: source scripts/config.sh
    Runner->>Config: configure_environment()
    Config-->>Runner: environment ready

    Runner->>Auth: source scripts/auth.sh
    Runner->>Auth: authenticate()
    Auth->>AP: POST /accounts/api/v2/oauth2/token
    AP-->>Auth: { access_token }
    Auth->>AP: GET /exchange/api/v2/assets    <!-- token validation -->
    AP-->>Auth: HTTP 200
    Auth-->>Runner: ACCESS_TOKEN set

    Runner->>MavenScript: source scripts/maven.sh
    Runner->>MavenScript: setup_maven_info()
    MavenScript->>Maven: get_pom_property(...)
    Maven-->>MavenScript: artifactId, groupId, version
    MavenScript->>FS: find target/*.jar
    FS-->>MavenScript: JAR path
    MavenScript-->>Runner: ARTIFACT_ID & JAR_FILE set

    Runner->>ExchangeScript: source scripts/exchange.sh
    Runner->>ExchangeScript: deploy_to_exchange()
    ExchangeScript->>ExchangeAPI: GET /exchange/api/v2/assets/…
    ExchangeAPI-->>ExchangeScript: HTTP 404 or 200
    ExchangeScript->>ExchangeAPI: POST or multipart upload
    ExchangeAPI-->>ExchangeScript: HTTP 201/409
    ExchangeScript-->>Runner: deployment complete

    Runner-->>Runner: echo "✅ Exchange deployment completed"
```

---

### Full `deploy-exchange.yml` Snippet

```yaml
deploy-exchange:
  stage: deploy-exchange
  image: maven:3.9.6-eclipse-temurin-17
  needs:
    - job: build
      artifacts: true
  before_script:
    - apt-get update && apt-get install -y curl jq
    - mkdir -p .m2
    - cp .m2/settings.xml .m2/settings.xml || echo "Settings file not found"
    - chmod +x scripts/*.sh
  script:
    - source scripts/config.sh
    - configure_environment
    - source scripts/auth.sh
    - authenticate
    - source scripts/maven.sh
    - setup_maven_info
    - source scripts/exchange.sh
    - deploy_to_exchange
    - echo "✅ Exchange deployment completed"
```