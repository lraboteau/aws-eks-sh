# Mule CI/CD Templates Module

This repository contains centralized GitLab CI/CD templates for MuleSoft applications deployment to Anypoint Platform.

## 🚀 Features

- **Build Template**: Compile and package Mule applications with Connected App authentication
- **Exchange Deployment**: Deploy applications to Anypoint Exchange
- **Runtime Fabric Deployment**: Deploy applications to Runtime Fabric targets
- **OAuth Authentication**: Secure authentication using Connected Apps
- **Maven Configuration**: Automated Maven settings generation

## 📁 Structure

```
rtf-gitlab-ci/
├── templates/
│   ├── build.yml              # Build template with OAuth authentication
│   ├── deploy-exchange.yml     # Exchange deployment template
│   └── deploy-rtf.yml         # Runtime Fabric deployment template
├── scripts/
│   ├── config.sh              # Environment configuration
│   ├── auth.sh                # Authentication helpers
│   ├── maven.sh               # Maven utilities
│   ├── exchange.sh            # Exchange deployment logic
│   └── deployment.sh          # RTF deployment logic
└── README.md
```

## 🛠️ Usage

### Basic Usage

Include the templates in your project's `.gitlab-ci.yml`:

```yaml
include:
  - project: 'coumets/rtf-gitlab-ci'
    ref: 'main'
    file: 'templates/build.yml'
  - project: 'coumets/rtf-gitlab-ci'
    ref: 'main'
    file: 'templates/deploy-exchange.yml'
  - project: 'coumets/rtf-gitlab-ci'
    ref: 'main'
    file: 'templates/deploy-rtf.yml'

stages:
  - build
  - deploy-exchange
  - deploy-rtf

variables:
  MAVEN_OPTS: "-Dmaven.repo.local=.m2/repository"
  MAVEN_CLI_OPTS: "-s .m2/settings.xml --batch-mode --errors --fail-at-end --show-version"

cache:
  paths:
    - .m2/repository/

# Your jobs here...
```

### Required CI/CD Variables

Configure these variables in your project's CI/CD settings:

| Variable | Description | Required | Masked | Protected |
|----------|-------------|----------|--------|-----------|
| `CLIENT_ID` | Anypoint Connected App Client ID | ✅ | ❌ | ✅ |
| `CLIENT_SECRET` | Anypoint Connected App Client Secret | ✅ | ✅ | ✅ |
| `RTF_ACCESS_TOKEN` | Access token for this repository | ✅ | ✅ | ✅ |

### Environment Variables (Optional)

| Variable | Description | Default |
|----------|-------------|---------|
| `ANYPOINT_ORG_ID` | Anypoint Organization ID | - |
| `ANYPOINT_ENV_ID` | Anypoint Environment ID | - |
| `RTF_TARGET_NAME` | Runtime Fabric target name | - |
| `RTF_REPLICAS` | Number of replicas | `1` |
| `RTF_VCORES` | vCores allocation | `0.1` |

## 🔧 Templates Description

### `.build_template`

Compiles and packages Mule applications with:
- OAuth token acquisition from Anypoint Platform
- Maven settings.xml generation with Bearer token
- Artifact creation (JAR files)

### `deploy-exchange`

Deploys applications to Anypoint Exchange with:
- Automated authentication
- Exchange asset publication
- Version management

### `deploy-rtf`

Deploys applications to Runtime Fabric with:
- Target configuration
- Scaling parameters
- Health checks

## 📋 Prerequisites

### Anypoint Platform Setup

1. **Create a Connected App** in Anypoint Platform:
   - Go to Access Management > Connected Apps
   - Create new Connected App
   - Grant required permissions:
     - Exchange Contributor
     - Runtime Manager
     - Design Center Developer

2. **Configure Runtime Fabric** (if using RTF deployment):
   - Ensure RTF is properly configured
   - Have target names ready

### GitLab Setup

1. **Repository Access**:
   - Create a Project Access Token in this repository
   - Grant `read_repository` permission
   - Add token as `RTF_ACCESS_TOKEN` variable in consuming projects

## 🔄 Versioning

This module follows semantic versioning. Use specific tags for production:

```yaml
include:
  - project: 'coumets/rtf-gitlab-ci'
    ref: 'v1.0.0'  # Use specific version instead of 'main'
    file: 'templates/build.yml'
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with a sample project
5. Submit a pull request

## 📝 Changelog

### v1.0.0
- Initial release
- Build template with OAuth authentication
- Exchange and RTF deployment templates
- Support for Connected Apps

## 📧 Support

For issues and questions:
- Create an issue in this repository
- Contact the DevOps team

## 📄 License

Internal use only - Coumets Organization# rtf-gitlab-ci

