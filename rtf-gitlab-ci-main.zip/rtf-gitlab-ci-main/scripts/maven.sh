#!/bin/bash

# Maven Project Information Extraction
# Filename: maven.sh

# Function to extract properties from pom.xml
get_pom_property() {
    local property=$1
    if [ -f ".m2/settings.xml" ]; then
        mvn -s .m2/settings.xml help:evaluate -Dexpression=${property} -q -DforceStdout 2>/dev/null
    else
        mvn help:evaluate -Dexpression=${property} -q -DforceStdout 2>/dev/null
    fi
}

# Function to extract and validate project information
extract_project_info() {
    echo "🔍 Extracting project information from pom.xml..."
    
    local artifact_id=$(get_pom_property "project.artifactId")
    local group_id=$(get_pom_property "project.groupId")
    local project_version=$(get_pom_property "project.version")
    
    # Verify Maven properties were retrieved
    if [ -z "$artifact_id" ] || [ -z "$group_id" ] || [ -z "$project_version" ]; then
        echo "❌ Error: Unable to retrieve Maven properties from pom.xml"
        echo "Artifact ID: '$artifact_id'"
        echo "Group ID: '$group_id'"
        echo "Project Version: '$project_version'"
        echo "Current directory: $(pwd)"
        echo "POM file exists: $([ -f pom.xml ] && echo 'Yes' || echo 'No')"
        exit 1
    fi
    
    # Build application version (remove SNAPSHOT for Exchange)
    local app_version
    if [[ "$project_version" == *"-SNAPSHOT"* ]]; then
        # Remove -SNAPSHOT and add pipeline ID
        local clean_version="${project_version%-SNAPSHOT}"
        app_version="${clean_version}-${CI_PIPELINE_IID}"
    else
        # Release version, add pipeline ID
        app_version="${project_version}-${CI_PIPELINE_IID}"
    fi
    
    # For Exchange, use ORG_ID as groupId instead of pom.xml groupId
    local exchange_group_id="$ORG_ID"
    
    # Export variables for use in other scripts
    export ARTIFACT_ID="$artifact_id"
    export GROUP_ID="$group_id"
    export PROJECT_VERSION="$project_version"
    export APP_VERSION="$app_version"
    export EXCHANGE_GROUP_ID="$exchange_group_id"
    
    echo "📋 Project Information:"
    echo "   Artifact ID: $artifact_id"
    echo "   Group ID (pom.xml): $group_id"
    echo "   Exchange Group ID: $exchange_group_id (Organization UUID)"
    echo "   Project Version: $project_version"
    echo "   App Version (for Exchange): $app_version"
    echo "   Application Name: $APP_NAME"
    
    echo "✅ Project information extracted successfully"
}

# Function to find JAR file in target directory
find_jar_file() {
    echo "📁 Looking for JAR file in target directory..."
    
    local jar_file=$(find target -name "*-mule-application.jar" | head -n 1)
    if [ -z "$jar_file" ]; then
        jar_file=$(find target -name "*.jar" | head -n 1)
    fi
    
    if [ -z "$jar_file" ]; then
        echo "❌ No JAR file found in target/"
        echo "Contents of target directory:"
        ls -la target/ || echo "target directory not found"
        exit 1
    fi
    
    export JAR_FILE="$jar_file"
    echo "📁 JAR file found: $jar_file"
    echo "📊 File size: $(du -h "$jar_file" | cut -f1)"
    
    return 0
}

# Main maven function
setup_maven_info() {
    extract_project_info
    find_jar_file
}