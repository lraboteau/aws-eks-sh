#!/bin/bash

# Anypoint Exchange Operations
# Filename: exchange.sh

# Function to check if asset exists on Exchange
verify_exchange_asset() {
    local exchange_group_id=$1
    local artifact_id=$2
    local app_version=$3
    
    echo "🔍 Checking asset existence on Exchange..."
    
    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_BASE_URL}/exchange/api/v2/assets/${exchange_group_id}/${artifact_id}/${app_version}" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [[ "$http_code" == "200" ]]; then
        echo "✅ Asset found on Exchange"
        # Parse and display key information
        local asset_name=$(echo "$body" | jq -r '.name // "N/A"')
        local asset_type=$(echo "$body" | jq -r '.type // "N/A"')
        local created_date=$(echo "$body" | jq -r '.createdDate // "N/A"')
        echo "📋 Asset Details: Name=$asset_name, Type=$asset_type, Created=$created_date"
        return 0
    else
        echo "❌ Asset not found on Exchange (HTTP $http_code)"
        return 1
    fi
}

# Function to publish artifact to Exchange via API
publish_to_exchange_api() {
    local exchange_group_id=$1
    local artifact_id=$2
    local app_version=$3
    local jar_file=$4
    
    echo "📦 Publishing artifact to Anypoint Exchange via API..."
    echo "   Exchange Group ID: $exchange_group_id (Organization UUID)"
    echo "   Artifact ID: $artifact_id"
    echo "   Version: $app_version"
    echo "   Organization ID: $ORG_ID"
    echo "   JAR file: $jar_file"
    
    # Upload to Exchange via API
    echo "🌐 Uploading to ${ANYPOINT_BASE_URL}/exchange/api/v2/assets"
    
    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_BASE_URL}/exchange/api/v2/assets" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -F "organizationId=${ORG_ID}" \
        -F "groupId=${exchange_group_id}" \
        -F "assetId=${artifact_id}" \
        -F "version=${app_version}" \
        -F "name=${APP_NAME}" \
        -F "classifier=mule-application" \
        -F "asset=@${jar_file};type=application/java-archive")
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    echo "📡 HTTP Response: $http_code"
    if [ ${#body} -gt 200 ]; then
        echo "📄 Response Body (truncated): ${body:0:200}..."
    else
        echo "📄 Response Body: $body"
    fi
    
    if [[ "$http_code" == "200" || "$http_code" == "201" ]]; then
        echo "✅ Exchange publication successful (HTTP $http_code)"
        return 0
    elif [[ "$http_code" == "409" ]]; then
        echo "ℹ️ Artifact already exists on Exchange (HTTP $http_code)"
        return 0
    else
        echo "❌ Error during Exchange publication (HTTP $http_code)"
        echo "📄 Full response body: $body"
        return 1
    fi
}

# Main function to publish to Exchange
publish_to_exchange() {
    local exchange_group_id=$1
    local artifact_id=$2
    local app_version=$3
    local jar_file=$4
    
    echo "🎯 Starting Exchange publication (API-ONLY MODE)"
    echo "   Exchange Group ID: $exchange_group_id (Organization UUID)"
    echo "   Artifact ID: $artifact_id" 
    echo "   Version: $app_version"
    echo "   NOTE: Skipping Maven deployment - using Exchange API only"
    
    # Check if asset already exists
    if verify_exchange_asset "$exchange_group_id" "$artifact_id" "$app_version"; then
        echo "ℹ️ Asset already exists on Exchange, no need to republish"
        return 0
    fi
    
    # Publish directly via Exchange API
    echo "🔄 Publishing via Exchange API..."
    if publish_to_exchange_api "$exchange_group_id" "$artifact_id" "$app_version" "$jar_file"; then
        # Verify API publication worked
        sleep 2  # Wait for propagation
        if verify_exchange_asset "$exchange_group_id" "$artifact_id" "$app_version"; then
            echo "✅ Exchange publication completed successfully"
            return 0
        else
            echo "⚠️ API publication succeeded but asset not immediately visible on Exchange"
            echo "ℹ️ This may be due to propagation delay - continuing with deployment"
            return 0
        fi
    fi
    
    echo "❌ Exchange publication failed"
    return 1
}

# Wrapper function for easy calling
deploy_to_exchange() {
    if ! publish_to_exchange "$EXCHANGE_GROUP_ID" "$ARTIFACT_ID" "$APP_VERSION" "$JAR_FILE"; then
        echo "❌ Exchange deployment failed"
        exit 1
    fi
    
    echo "✅ Exchange deployment completed successfully"
}