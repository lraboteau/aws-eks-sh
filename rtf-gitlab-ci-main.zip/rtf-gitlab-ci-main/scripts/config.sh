#!/bin/bash

# Configuration and Environment Setup
# Filename: config.sh

# US control plane configuration
export ANYPOINT_BASE_URL="https://anypoint.mulesoft.com"
export ANYPOINT_API_URL="https://anypoint.mulesoft.com/amc/application-manager/api/v2"

# Default configuration
export DEFAULT_CPU_LIMIT="1000m"
export DEFAULT_CPU_RESERVED="200m"
export DEFAULT_MEMORY_LIMIT="1Gi"
export DEFAULT_MEMORY_RESERVED="1Gi"
export DEFAULT_REPLICAS=1

# Function to validate required environment variables
validate_environment() {
    local required_vars=(
        "CI_PIPELINE_IID"
        "CLIENT_ID"
        "CLIENT_SECRET"
        "ORG_ID"
        "ENVIRONMENT_ID"
        "TARGET_ID"
        "CI_PROJECT_NAME"
        "CI_COMMIT_SHA"
    )
    
    local missing_vars=()
    
    for var in "${required_vars[@]}"; do
        if [ -z "${!var}" ]; then
            missing_vars+=("$var")
        fi
    done
    
    if [ ${#missing_vars[@]} -ne 0 ]; then
        echo "❌ Error: Missing required environment variables:"
        printf "   - %s\n" "${missing_vars[@]}"
        exit 1
    fi
    
    echo "✅ All required environment variables are set"
}

# Function to set up application name
setup_app_name() {
    if [ -n "$MULE_APP_NAME" ]; then
        export APP_NAME="$MULE_APP_NAME"
    else
        export APP_NAME="muleapp-${CI_PROJECT_NAME}"
    fi
    
    echo "📱 Application name: $APP_NAME"
}

# Function to check for required tools
check_dependencies() {
    local required_tools=("jq" "curl" "mvn")
    local missing_tools=()
    
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    if [ ${#missing_tools[@]} -ne 0 ]; then
        echo "❌ Error: Missing required tools:"
        printf "   - %s\n" "${missing_tools[@]}"
        exit 1
    fi
    
    echo "✅ All required tools are available"
}

# Function to display deployment summary
display_summary() {
    echo "=== RTF MuleSoft Deployment - US Control Plane (API-ONLY MODE) ==="
    echo "Project: $CI_PROJECT_NAME"
    echo "App Name: $APP_NAME"
    echo "Pipeline ID: $CI_PIPELINE_IID"
    echo "Commit SHA: ${CI_COMMIT_SHA:0:8}"
    echo "⚠️ NOTE: This version skips Maven deployment and uses Exchange API only"
}

# Main configuration function
configure_environment() {
    echo "🔧 Setting up deployment environment..."
    
    display_summary
    validate_environment
    setup_app_name
    check_dependencies
    
    echo "✅ Environment configuration completed"
}