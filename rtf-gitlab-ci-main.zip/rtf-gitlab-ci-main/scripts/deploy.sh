#!/bin/bash

# Main Deployment Orchestrator
# Filename: deploy.sh

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source all module scripts
source "${SCRIPT_DIR}/config.sh"
source "${SCRIPT_DIR}/auth.sh"
source "${SCRIPT_DIR}/maven.sh"
source "${SCRIPT_DIR}/exchange.sh"
source "${SCRIPT_DIR}/deployment.sh"

# Function to display final summary
display_final_summary() {
    echo "=== Deployment completed ==="
    echo "🎉 Success! Application '$APP_NAME' has been deployed to Runtime Fabric"
    echo "📦 Published to Exchange: $EXCHANGE_GROUP_ID:$ARTIFACT_ID:$APP_VERSION"
    echo "🌐 Control Plane: $ANYPOINT_BASE_URL"
    echo "📊 Deployment Details:"
    echo "   - Organization: $ORG_ID"
    echo "   - Environment: $ENVIRONMENT_ID"
    echo "   - Target: $TARGET_ID"
    echo "   - Pipeline: $CI_PIPELINE_IID"
    echo "   - Commit: ${CI_COMMIT_SHA:0:8}"
}

# Main execution function
main() {
    echo "🚀 Starting MuleSoft RTF Deployment Pipeline..."
    
    # Step 1: Configure environment and validate prerequisites
    configure_environment
    
    # Step 2: Authenticate with Anypoint Platform
    authenticate
    
    # Step 3: Extract Maven project information
    setup_maven_info
    
    # Step 4: Deploy to Anypoint Exchange
    deploy_to_exchange
    
    # Step 5: Deploy to Runtime Fabric
    deploy_to_runtime_fabric
    
    # Step 6: Display final summary
    display_final_summary
    
    echo "✅ Deployment pipeline completed successfully!"
}

# Error handling
set -e  # Exit on any error

# Trap to handle cleanup on exit
trap 'echo "❌ Deployment pipeline failed at step: $BASH_COMMAND"' ERR

# Execute main function
main "$@"