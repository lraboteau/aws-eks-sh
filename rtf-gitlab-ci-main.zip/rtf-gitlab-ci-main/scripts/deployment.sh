#!/bin/bash

# Runtime Fabric Deployment Operations
# Filename: deployment.sh

# Function to check if application exists
get_app_deployment() {
    local response=$(curl -s "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    
    local app_id=$(echo "$response" | jq -r ".items[] | select(.name == \"$APP_NAME\").id")
    
    if [ "$app_id" != "null" ] && [ -n "$app_id" ]; then
        echo "$app_id"
    else
        echo ""
    fi
}

# Function to create deployment JSON
create_deployment_json() {
    local app_version=$1
    local artifact_id=$2
    local group_id=$3
    
    cat <<EOF
{
    "name": "${APP_NAME}",
    "labels": [],
    "target": {
        "provider": "MC",
        "targetId": "${TARGET_ID}",
        "deploymentSettings": {
            "resources": {
                "cpu": {
                    "limit": "${CPU_LIMIT:-$DEFAULT_CPU_LIMIT}",
                    "reserved": "${CPU_RESERVED:-$DEFAULT_CPU_RESERVED}"
                },
                "memory": {
                    "limit": "${MEMORY_LIMIT:-$DEFAULT_MEMORY_LIMIT}",
                    "reserved": "${MEMORY_RESERVED:-$DEFAULT_MEMORY_RESERVED}"
                }
            },
            "clustered": false,
            "enforceDeployingReplicasAcrossNodes": true,
            "http": {
                "inbound": {
                    "publicUrl": "${PUBLIC_URL:-}"
                }
            },
            "jvm": {},
            "runtimeVersion": "",
            "lastMileSecurity": true,
            "updateStrategy": "rolling",
            "disableAmLogForwarding": true,
            "runtime": {
                "releaseChannel": "LTS",
                "java": "17"
            }
        },
        "replicas": ${REPLICAS:-$DEFAULT_REPLICAS}
    },
    "application": {
        "ref": {
            "groupId": "${group_id}",
            "artifactId": "${artifact_id}",
            "version": "${app_version}",
            "packaging": "jar"
        },
        "assets": [],
        "desiredState": "STARTED",
        "configuration": {
            "mule.agent.application.properties.service": {
                "applicationName": "${APP_NAME}",
                "properties": {
                    "anypoint.platform.analytics_base_uri": "",
                    "anypoint.platform.base_uri": "${ANYPOINT_BASE_URL}",
                    "deploy.application.name": "${APP_NAME}",
                    "anypoint.platform.config.analytics.agent.enabled": "true"
                },
                "secureProperties": {
                    "config.encryptionkey": "${CONFIG_ENCRYPTION_KEY:-}"
                }
            }
        }
    }
}
EOF
}

# Function to deploy new application
deploy_new_app() {
    local deployment_json=$1
    
    echo "🚀 Deploying new application..."
    
    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -X POST \
        -d "$deployment_json")
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [[ "$http_code" == "200" || "$http_code" == "202" ]]; then
        echo "✅ Deployment successful (HTTP $http_code)"
        # Parse deployment ID from response
        local deployment_id=$(echo "$body" | jq -r '.id // "N/A"')
        local deployment_status=$(echo "$body" | jq -r '.status // "N/A"')
        echo "📋 Deployment ID: $deployment_id"
        echo "📊 Initial Status: $deployment_status"
        return 0
    else
        echo "❌ Deployment error (HTTP $http_code)"
        echo "📄 Response: $body"
        return 1
    fi
}

# Function to update existing application
update_existing_app() {
    local app_id=$1
    local deployment_json=$2
    
    echo "🔄 Updating existing application (ID: $app_id)..."
    
    local response=$(curl -s -w "%{http_code}" \
        "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments/${app_id}" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -X PATCH \
        -d "$deployment_json")
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [[ "$http_code" == "200" || "$http_code" == "202" ]]; then
        echo "✅ Update successful (HTTP $http_code)"
        # Parse deployment info from response
        local deployment_status=$(echo "$body" | jq -r '.status // "N/A"')
        local app_status=$(echo "$body" | jq -r '.application.status // "N/A"')
        echo "📊 Deployment Status: $deployment_status"
        echo "📱 Application Status: $app_status"
        return 0
    else
        echo "❌ Update error (HTTP $http_code)"
        echo "📄 Response: $body"
        return 1
    fi
}

# Function to wait for deployment completion
wait_for_deployment() {
    local app_id=$1
    local max_wait=${DEPLOYMENT_TIMEOUT:-300}  # 5 minutes default
    local wait_time=0
    local check_interval=10
    
    if [ "$WAIT_FOR_DEPLOYMENT" != "true" ]; then
        echo "ℹ️ Skipping deployment status check (WAIT_FOR_DEPLOYMENT not set to true)"
        return 0
    fi
    
    echo "⏳ Waiting for deployment to complete (max ${max_wait}s)..."
    
    while [ $wait_time -lt $max_wait ]; do
        local response=$(curl -s "${ANYPOINT_API_URL}/organizations/${ORG_ID}/environments/${ENVIRONMENT_ID}/deployments/${app_id}" \
            -H "Authorization: Bearer $ACCESS_TOKEN")
        
        local deployment_status=$(echo "$response" | jq -r '.status // "UNKNOWN"')
        local app_status=$(echo "$response" | jq -r '.application.status // "UNKNOWN"')
        
        echo "📊 Status check: Deployment=$deployment_status, Application=$app_status"
        
        if [[ "$deployment_status" == "DEPLOYED" && "$app_status" == "RUNNING" ]]; then
            echo "✅ Deployment completed successfully!"
            return 0
        elif [[ "$deployment_status" == "FAILED" || "$app_status" == "FAILED" ]]; then
            echo "❌ Deployment failed!"
            return 1
        fi
        
        sleep $check_interval
        wait_time=$((wait_time + check_interval))
    done
    
    echo "⏰ Deployment timeout reached (${max_wait}s)"
    return 1
}

# Main deployment function
deploy_to_runtime_fabric() {
    echo "🚀 Starting Runtime Fabric deployment..."
    
    # Check for existing application
    echo "🔍 Checking for existing application: $APP_NAME"
    local existing_app_id=$(get_app_deployment)
    
    # Create deployment JSON
    echo "🔧 Creating deployment JSON..."
    local deployment_json=$(create_deployment_json "$APP_VERSION" "$ARTIFACT_ID" "$EXCHANGE_GROUP_ID")
    
    # Display deployment summary
    echo "📄 Deployment Summary:"
    echo "   Target ID: $TARGET_ID"
    echo "   Organization ID: $ORG_ID"
    echo "   Environment ID: $ENVIRONMENT_ID"
    echo "   Asset Reference: $EXCHANGE_GROUP_ID:$ARTIFACT_ID:$APP_VERSION"
    echo "   Deployment Method: Exchange API Only (Maven skipped)"
    
    # Deploy or update
    if [ -z "$existing_app_id" ]; then
        echo "📦 Application not found - Deploying new application"
        if deploy_new_app "$deployment_json"; then
            # Get the new app ID for status checking
            sleep 2
            local new_app_id=$(get_app_deployment)
            if [ -n "$new_app_id" ]; then
                wait_for_deployment "$new_app_id"
            fi
        else
            echo "❌ New application deployment failed"
            exit 1
        fi
    else
        echo "🔄 Application found with ID: $existing_app_id - Updating"
        if update_existing_app "$existing_app_id" "$deployment_json"; then
            wait_for_deployment "$existing_app_id"
        else
            echo "❌ Application update failed"
            exit 1
        fi
    fi
    
    echo "✅ Runtime Fabric deployment completed successfully"
}