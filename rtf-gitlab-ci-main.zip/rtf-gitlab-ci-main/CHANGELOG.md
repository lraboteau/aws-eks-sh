# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2025-01-18

### Added
- Initial release of Mule CI/CD templates module
- Build template with OAuth authentication using Connected Apps
- Exchange deployment template with automated authentication
- Runtime Fabric deployment template with scaling configuration
- Support scripts for configuration, authentication, and deployment
- Maven settings.xml generation with Bearer token authentication
- Artifact management and caching optimization
- Documentation and usage examples

### Features
- **OAuth Authentication**: Secure authentication using Anypoint Connected Apps
- **Maven Integration**: Automated Maven configuration with repository authentication
- **Exchange Deployment**: Automated deployment to Anypoint Exchange
- **RTF Deployment**: Automated deployment to Runtime Fabric with custom scaling
- **Script Management**: Centralized bash scripts for common operations
- **Error Handling**: Comprehensive error handling and logging

### Security
- Bearer token authentication for Maven repositories
- Masked sensitive variables in CI/CD pipeline
- Secure credential management through GitLab variables

### Performance
- Optimized artifact caching
- Parallel job execution with `needs` dependencies
- Minimal resource usage with Alpine-based images

---

## Template for Future Releases

## [X.Y.Z] - YYYY-MM-DD

### Added
- New features

### Changed
- Changes in existing functionality

### Deprecated
- Soon-to-be removed features

### Removed
- Removed features

### Fixed
- Bug fixes

### Security
- Security improvements